﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_IS
{
    public partial class InicioMedicos : Form
    {
       // private int id_Medico;
        //Ruta de conexion de la base de datos
        static string conexionruta = "server = TRISTAN\\MSSQLSERVER01; integrated security = true ; database = Proyecto_IS";
        //Genera el objeto conexion para enlazar la base de datos
        SqlConnection conexion = new SqlConnection(conexionruta);
        
        public InicioMedicos()
        {
            //Al cargar el formulario muestra los Pacientes que estan registrados en la base de datos
            InitializeComponent();
            //Inicia la conexion
            conexion.Open();
            //Comando para cargar los valor de la tabla Paciente en el DataGridView del programa
            string query = "Select * from Paciente WHERE id_Medico = @id_Medico";
            using (SqlConnection conexion = new SqlConnection(conexionruta))
            using (SqlCommand comando = new SqlCommand(query, conexion)) 
            {
                comando.Parameters.AddWithValue("@id_Medico", SesionActual.idMedico);
                SqlDataAdapter data = new SqlDataAdapter(comando);
                DataTable Paciente = new DataTable();
                data.Fill(Paciente);
                //Rellena la DGV con el contenido de la tabla Paciente
                dgv_HistorialMedico.DataSource = Paciente;
            }
        }

        private void btnNuevaConsulta_Click(object sender, EventArgs e)
        {
            conexion.Close();
            NuevaConsulta consulta = new NuevaConsulta();
            consulta.Show();
            this.Close();
        }

        private void btnCerrar_Sesion_Click(object sender, EventArgs e)
        {
            Form1 menu = new Form1();  
            menu.Show();
            this.Close();
        }
    }
}
