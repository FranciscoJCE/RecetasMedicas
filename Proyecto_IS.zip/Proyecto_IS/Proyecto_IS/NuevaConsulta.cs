﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_IS
{
    public partial class NuevaConsulta : Form
    {
        public NuevaConsulta()
        {
            InitializeComponent();
            txt_idMedico.Text = Convert.ToString(SesionActual.idMedico);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Ruta de conexion de la base de datos
            string conexionruta = "server = TRISTAN\\MSSQLSERVER01; integrated security = true ; database = Proyecto_IS";
            //Genera el objeto conexion para enlazar la base de datos
            SqlConnection conexion = new SqlConnection(conexionruta);
            if (!string.IsNullOrWhiteSpace(txt_NumeroSS.Text) &&
            !string.IsNullOrWhiteSpace(txt_NombrePaciente.Text) &&
            !string.IsNullOrWhiteSpace(txt_ApellidosPaciente.Text))
            {
                string cadena = "INSERT INTO Paciente ([nom_Paciente], [apellido_Paciente], [id_Medico], [num_SeguroS]) " +
                                "VALUES (@nombre, @apellido, @idMedico, @numSS)";

                using (SqlCommand insertar = new SqlCommand(cadena, conexion))
                {
                    insertar.Parameters.AddWithValue("@nombre", txt_NombrePaciente.Text);
                    insertar.Parameters.AddWithValue("@apellido", txt_ApellidosPaciente.Text);
                    insertar.Parameters.AddWithValue("@idMedico", txt_idMedico.Text);
                    insertar.Parameters.AddWithValue("@numSS", txt_NumeroSS.Text);

                    conexion.Open();
                    insertar.ExecuteNonQuery();
                    conexion.Close();

                    MessageBox.Show("Paciente registrado correctamente.");
                    this.Close();
                    InicioMedicos inicioMed = new InicioMedicos();
                    inicioMed.Show();
                }
            }
            else
            {
                MessageBox.Show("Por favor, completa todos los campos antes de guardar.");
            }

        }
        InicioMedicos inicio = new InicioMedicos();
        private void button2_Click(object sender, EventArgs e)
        {
            inicio.Show();
            this.Close();
        }
    }
}
