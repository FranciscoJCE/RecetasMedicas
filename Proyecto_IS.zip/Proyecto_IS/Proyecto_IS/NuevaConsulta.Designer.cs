﻿namespace Proyecto_IS
{
    partial class NuevaConsulta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_idPaciente = new System.Windows.Forms.TextBox();
            this.txt_ApellidosPaciente = new System.Windows.Forms.TextBox();
            this.txt_idMedico = new System.Windows.Forms.TextBox();
            this.txt_NumeroSS = new System.Windows.Forms.TextBox();
            this.txt_NombrePaciente = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_idPaciente
            // 
            this.txt_idPaciente.Location = new System.Drawing.Point(163, 29);
            this.txt_idPaciente.Name = "txt_idPaciente";
            this.txt_idPaciente.Size = new System.Drawing.Size(239, 22);
            this.txt_idPaciente.TabIndex = 0;
            // 
            // txt_ApellidosPaciente
            // 
            this.txt_ApellidosPaciente.Location = new System.Drawing.Point(163, 127);
            this.txt_ApellidosPaciente.Name = "txt_ApellidosPaciente";
            this.txt_ApellidosPaciente.Size = new System.Drawing.Size(239, 22);
            this.txt_ApellidosPaciente.TabIndex = 1;
            // 
            // txt_idMedico
            // 
            this.txt_idMedico.Enabled = false;
            this.txt_idMedico.Location = new System.Drawing.Point(163, 193);
            this.txt_idMedico.Name = "txt_idMedico";
            this.txt_idMedico.Size = new System.Drawing.Size(239, 22);
            this.txt_idMedico.TabIndex = 2;
            // 
            // txt_NumeroSS
            // 
            this.txt_NumeroSS.Location = new System.Drawing.Point(163, 250);
            this.txt_NumeroSS.Name = "txt_NumeroSS";
            this.txt_NumeroSS.Size = new System.Drawing.Size(239, 22);
            this.txt_NumeroSS.TabIndex = 3;
            // 
            // txt_NombrePaciente
            // 
            this.txt_NombrePaciente.Location = new System.Drawing.Point(163, 75);
            this.txt_NombrePaciente.Name = "txt_NombrePaciente";
            this.txt_NombrePaciente.Size = new System.Drawing.Size(239, 22);
            this.txt_NombrePaciente.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "id_Paciente";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Nombres";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Apellidos";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(28, 196);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "id_Medico";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(28, 253);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "Numero de seguro";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(295, 355);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(107, 48);
            this.button1.TabIndex = 10;
            this.button1.Text = "Registrar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(31, 355);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(107, 48);
            this.button2.TabIndex = 11;
            this.button2.Text = "cerrar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // NuevaConsulta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(444, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_NombrePaciente);
            this.Controls.Add(this.txt_NumeroSS);
            this.Controls.Add(this.txt_idMedico);
            this.Controls.Add(this.txt_ApellidosPaciente);
            this.Controls.Add(this.txt_idPaciente);
            this.Name = "NuevaConsulta";
            this.Text = "NuevaConsulta";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_idPaciente;
        private System.Windows.Forms.TextBox txt_ApellidosPaciente;
        private System.Windows.Forms.TextBox txt_idMedico;
        private System.Windows.Forms.TextBox txt_NumeroSS;
        private System.Windows.Forms.TextBox txt_NombrePaciente;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}