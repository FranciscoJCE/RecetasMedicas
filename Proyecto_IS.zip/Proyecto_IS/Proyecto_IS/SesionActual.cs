﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_IS
{
    internal class SesionActual
    {
        public static int idMedico { get; set; }
        public static string Usuario { get; set; }

        public static void CerrarSesion()
        {
            idMedico = 0;
            Usuario = null;
        }
    }
}
