﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Proyecto_IS
{
    public partial class LoginFarmaceutico : Form
    {
        public LoginFarmaceutico()
        {
            InitializeComponent();
        }
        //Boton regresar al menú
        private void button2_Click(object sender, EventArgs e)
        {
            //Generar instancia del formulario 1
            Form1 men = new Form1();
            //Mostrar el menu
            men.Show();
            //Cerrar la ventana LoginFarmaceutico
            this.Close();  
        }
        //Salir del programa
        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //En caso de que se inicie sesión
        private void button1_Click(object sender, EventArgs e)
        {
            //Variables para identificar el usuario y contraseña
            string usuario = txt_UsuarioFarmaceutico.Text;
            string contraseña = txt_ContraFarmaceutico.Text;

            //Ruta de conexion para enlazar el programa a la base de datos
            string conexionruta = "server = LAPTOP-L3VPSIHP\\SQLEXPRESS01; integrated security = true ; database = Proyecto_IS";
            //Comando para afectar el registro de LogMedicos
            string query = "Select * from LogFarm WHERE contraseña = @contraseña AND usuario = @usuario";
            //Comandos para verificar que el usuario y la constraseña se encuentren en la base de datos
            using (SqlConnection conexion = new SqlConnection(conexionruta))
            using (SqlCommand comando = new SqlCommand(query, conexion))
            {
                //Asignacion de parametros del comando para darle valor al usuario y la contraseña en las variables declaradas
                comando.Parameters.AddWithValue("@usuario", usuario);
                comando.Parameters.AddWithValue("@contraseña", contraseña);
                //Enlaza la base de datos con el programa
                conexion.Open();
                //Verifica la informacion del comando "query"
                SqlDataReader reader = comando.ExecuteReader();

                //Si los datos ingresados en la ventana login coniciden con la información guardada en la base de datos muestra el menu de inicio de los medicos
                if (reader.HasRows)
                {
                    //int idMedico = reader.GetInt32(0);
                    InicioMedicos inicio = new InicioMedicos();
                    inicio.Show();
                    this.Close();
                }
                //En caso de que el usuario o la contraseña sean incorrectos muestra una ventana con el siguiente mensaje
                else
                {
                    MessageBox.Show("Usuario o contraseña incorrectos");
                }
            }
        }

        private void txt_ContraFarmaceutico_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
