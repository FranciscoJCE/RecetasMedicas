﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_IS
{
    internal class IndiceMedicamentos
    {
        public int id_Medicamento {  get; set; }
        public string nom_Medicamento { get; set; }

        public override string ToString()
        {
            return nom_Medicamento;
        }
    }
}
