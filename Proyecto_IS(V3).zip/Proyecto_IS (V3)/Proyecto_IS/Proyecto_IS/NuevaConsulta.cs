﻿using Mysqlx.Crud;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Proyecto_IS
{
    public partial class NuevaConsulta : Form
    {
        public NuevaConsulta()
        {
            InitializeComponent();
            txt_idMedico.Text = Convert.ToString(SesionActual.idMedico);
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            string conexionruta = "server = LAPTOP-L3VPSIHP\\SQLEXPRESS01; integrated security = true ; database = Proyecto_IS";

            // Validar campos obligatorios
            if (string.IsNullOrWhiteSpace(txt_NombrePaciente.Text) ||
                string.IsNullOrWhiteSpace(txt_ApellidosPaciente.Text) ||
                string.IsNullOrWhiteSpace(txt_NumeroSS.Text) ||
                string.IsNullOrWhiteSpace(txt_idMedico.Text) ||
                string.IsNullOrWhiteSpace(txt_Sintomas.Text))
            {
                MessageBox.Show("Por favor, completa todos los campos antes de guardar.");
                return;
            }

            using (SqlConnection conexion = new SqlConnection(conexionruta))
            {
                conexion.Open();
                SqlTransaction transaccion = conexion.BeginTransaction();

                try
                {
                    int idPaciente = 0;
                    int idReceta = 0;

                    // 1️⃣ Insertar el paciente y recuperar su ID
                    string insertarPaciente = @"
                INSERT INTO Paciente (nom_Paciente, apellido_Paciente, id_Medico, num_SeguroS)
                VALUES (@nombre, @apellido, @idMedico, @numSS);
                SELECT SCOPE_IDENTITY();";

                    using (SqlCommand cmdPaciente = new SqlCommand(insertarPaciente, conexion, transaccion))
                    {
                        cmdPaciente.Parameters.AddWithValue("@nombre", txt_NombrePaciente.Text);
                        cmdPaciente.Parameters.AddWithValue("@apellido", txt_ApellidosPaciente.Text);
                        cmdPaciente.Parameters.AddWithValue("@idMedico", Convert.ToInt32(txt_idMedico.Text));
                        cmdPaciente.Parameters.AddWithValue("@numSS", txt_NumeroSS.Text);

                        idPaciente = Convert.ToInt32(cmdPaciente.ExecuteScalar());
                    }

                    // 2️⃣ Insertar la receta y recuperar su ID
                    string insertarReceta = @"
                INSERT INTO Receta (sintomas, id_Paciente, id_Medico, fecha_Receta)
                VALUES (@sintomas, @idPaciente, @idMedico, @fecha);
                SELECT SCOPE_IDENTITY();";

                    using (SqlCommand cmdReceta = new SqlCommand(insertarReceta, conexion, transaccion))
                    {
                        cmdReceta.Parameters.AddWithValue("@sintomas", txt_Sintomas.Text);
                        cmdReceta.Parameters.AddWithValue("@idPaciente", idPaciente);
                        cmdReceta.Parameters.AddWithValue("@idMedico", Convert.ToInt32(txt_idMedico.Text));
                        cmdReceta.Parameters.AddWithValue("@fecha", DateTime.Now);

                        idReceta = Convert.ToInt32(cmdReceta.ExecuteScalar());
                    }

                    // 3️⃣ Insertar los medicamentos seleccionados
                    foreach (var item in clbMedicamentos.CheckedItems)
                    {
                        // Recuperar el objeto IndiceMedicamentos
                        IndiceMedicamentos med = item as IndiceMedicamentos;

                        if (med != null)
                        {
                            string insertarRecetaMed = @"
                        INSERT INTO RecetaMedicamento (id_Receta, id_Medicamento, dosis)
                        VALUES (@idReceta, @idMedicamento, @dosis);";

                            using (SqlCommand cmdRecetaMed = new SqlCommand(insertarRecetaMed, conexion, transaccion))
                            {
                                cmdRecetaMed.Parameters.AddWithValue("@idReceta", idReceta);
                                cmdRecetaMed.Parameters.AddWithValue("@idMedicamento", med.id_Medicamento);
                                cmdRecetaMed.Parameters.AddWithValue("@dosis", DBNull.Value); // Puedes reemplazar con un campo TextBox para la dosis
                                cmdRecetaMed.ExecuteNonQuery();
                            }
                        }
                    }

                    // 4️⃣ Confirmar todo
                    transaccion.Commit();
                    MessageBox.Show("Receta registrada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    InicioMedicos inicio = new InicioMedicos();
                    inicio.Show();
                    this.Close();
                }
                catch (Exception ex)
                {
                    transaccion.Rollback();
                    MessageBox.Show("Error al registrar la receta: " + ex.Message);
                }
            }

        }
        InicioMedicos inicio = new InicioMedicos();
        private void button2_Click(object sender, EventArgs e)
        {
            inicio.Show();
            this.Close();
        }

        private void NuevaConsulta_Load(object sender, EventArgs e)
        {
            string conexionruta = "server=TRISTAN\\MSSQLSERVER01; integrated security=true; database=Proyecto_IS";

            // 🔹 1. Mostrar el ID del médico que inició sesión
            txt_idMedico.Text = SesionActual.idMedico.ToString();

            // 🔹 2. Cargar medicamentos desde la base de datos
            using (SqlConnection conexion = new SqlConnection(conexionruta))
            {
                string consulta = "SELECT id_Medicamento, nom_Medicamento FROM Medicamento";
                SqlCommand comando = new SqlCommand(consulta, conexion);
                conexion.Open();

                SqlDataReader reader = comando.ExecuteReader();
                clbMedicamentos.Items.Clear(); // Limpia por si se recarga

                while (reader.Read())
                {
                    IndiceMedicamentos med = new IndiceMedicamentos
                    {
                        id_Medicamento = Convert.ToInt32(reader["id_Medicamento"]),
                        nom_Medicamento = reader["nom_Medicamento"].ToString()
                    };
                    clbMedicamentos.Items.Add(med);
                }

                reader.Close();
                conexion.Close();
            }

            // 🔹 3. Si hay un paciente seleccionado desde el formulario anterior, cargar su información
            if (SesionActual.idPacienteSeleccionado.HasValue)
            {
                int idPaciente = SesionActual.idPacienteSeleccionado.Value;

                using (SqlConnection conexion = new SqlConnection(conexionruta))
                {
                    conexion.Open();
                    string consultaPaciente = "SELECT nom_Paciente, apellido_Paciente, num_SeguroS FROM Paciente WHERE id_Paciente = @id";
                    SqlCommand cmd = new SqlCommand(consultaPaciente, conexion);
                    cmd.Parameters.AddWithValue("@id", idPaciente);

                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        txt_NombrePaciente.Text = dr["nom_Paciente"].ToString();
                        txt_ApellidosPaciente.Text = dr["apellido_Paciente"].ToString();
                        txt_NumeroSS.Text = dr["num_SeguroS"].ToString();

                        // Hacemos que los campos no se puedan editar
                        txt_NombrePaciente.ReadOnly = true;
                        txt_ApellidosPaciente.ReadOnly = true;
                        txt_NumeroSS.ReadOnly = true;
                    }
                    dr.Close();
                }
            }
            else
            {
                // Si no hay paciente seleccionado, los campos se mantienen editables
                txt_NombrePaciente.ReadOnly = false;
                txt_ApellidosPaciente.ReadOnly = false;
                txt_NumeroSS.ReadOnly = false;
            }
        }

    }
}
