﻿namespace Proyecto_IS
{
    partial class NuevoRegistrocs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NuevoRegistrocs));
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_NombrePaciente = new System.Windows.Forms.TextBox();
            this.txt_NumeroSS = new System.Windows.Forms.TextBox();
            this.txt_idMedico = new System.Windows.Forms.TextBox();
            this.txt_ApellidosPaciente = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(161)))), ((int)(((byte)(105)))));
            this.button2.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.button2.Location = new System.Drawing.Point(18, 288);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(80, 39);
            this.button2.TabIndex = 23;
            this.button2.Text = "Cerrar";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(161)))), ((int)(((byte)(105)))));
            this.button1.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.button1.Location = new System.Drawing.Point(231, 288);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(80, 39);
            this.button1.TabIndex = 22;
            this.button1.Text = "Registrar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.label5.Location = new System.Drawing.Point(16, 197);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "Número de seguro";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.label4.Location = new System.Drawing.Point(16, 254);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "ID Medico";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.label3.Location = new System.Drawing.Point(16, 144);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Apellídos";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.label2.Location = new System.Drawing.Point(16, 86);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Nombres";
            // 
            // txt_NombrePaciente
            // 
            this.txt_NombrePaciente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(211)))), ((int)(((byte)(145)))));
            this.txt_NombrePaciente.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.txt_NombrePaciente.Location = new System.Drawing.Point(131, 77);
            this.txt_NombrePaciente.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_NombrePaciente.Name = "txt_NombrePaciente";
            this.txt_NombrePaciente.Size = new System.Drawing.Size(180, 22);
            this.txt_NombrePaciente.TabIndex = 16;
            // 
            // txt_NumeroSS
            // 
            this.txt_NumeroSS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(211)))), ((int)(((byte)(145)))));
            this.txt_NumeroSS.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.txt_NumeroSS.Location = new System.Drawing.Point(131, 190);
            this.txt_NumeroSS.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_NumeroSS.Name = "txt_NumeroSS";
            this.txt_NumeroSS.Size = new System.Drawing.Size(180, 22);
            this.txt_NumeroSS.TabIndex = 15;
            // 
            // txt_idMedico
            // 
            this.txt_idMedico.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(211)))), ((int)(((byte)(145)))));
            this.txt_idMedico.Enabled = false;
            this.txt_idMedico.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.txt_idMedico.Location = new System.Drawing.Point(131, 247);
            this.txt_idMedico.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_idMedico.Name = "txt_idMedico";
            this.txt_idMedico.Size = new System.Drawing.Size(180, 22);
            this.txt_idMedico.TabIndex = 14;
            // 
            // txt_ApellidosPaciente
            // 
            this.txt_ApellidosPaciente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(211)))), ((int)(((byte)(145)))));
            this.txt_ApellidosPaciente.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.txt_ApellidosPaciente.Location = new System.Drawing.Point(131, 135);
            this.txt_ApellidosPaciente.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_ApellidosPaciente.Name = "txt_ApellidosPaciente";
            this.txt_ApellidosPaciente.Size = new System.Drawing.Size(180, 22);
            this.txt_ApellidosPaciente.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Malgun Gothic", 12F);
            this.label1.Location = new System.Drawing.Point(104, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 21);
            this.label1.TabIndex = 24;
            this.label1.Text = "Ingresar Registros";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Proyecto_IS.Properties.Resources.pngwing_com__2_;
            this.pictureBox1.Location = new System.Drawing.Point(19, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(64, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            // 
            // NuevoRegistrocs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(255)))), ((int)(((byte)(244)))));
            this.ClientSize = new System.Drawing.Size(344, 366);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_NombrePaciente);
            this.Controls.Add(this.txt_NumeroSS);
            this.Controls.Add(this.txt_idMedico);
            this.Controls.Add(this.txt_ApellidosPaciente);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "NuevoRegistrocs";
            this.Text = "Nuevo Registro";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_NombrePaciente;
        private System.Windows.Forms.TextBox txt_NumeroSS;
        private System.Windows.Forms.TextBox txt_idMedico;
        private System.Windows.Forms.TextBox txt_ApellidosPaciente;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}