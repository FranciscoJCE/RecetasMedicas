﻿namespace Proyecto_IS
{
    partial class NuevaConsulta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NuevaConsulta));
            this.txt_ApellidosPaciente = new System.Windows.Forms.TextBox();
            this.txt_idMedico = new System.Windows.Forms.TextBox();
            this.txt_NumeroSS = new System.Windows.Forms.TextBox();
            this.txt_NombrePaciente = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.txtFecha = new System.Windows.Forms.TextBox();
            this.txt_Sintomas = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.clbMedicamentos = new System.Windows.Forms.CheckedListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_ApellidosPaciente
            // 
            this.txt_ApellidosPaciente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(179)))), ((int)(((byte)(237)))));
            this.txt_ApellidosPaciente.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.txt_ApellidosPaciente.Location = new System.Drawing.Point(130, 98);
            this.txt_ApellidosPaciente.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_ApellidosPaciente.Name = "txt_ApellidosPaciente";
            this.txt_ApellidosPaciente.Size = new System.Drawing.Size(180, 22);
            this.txt_ApellidosPaciente.TabIndex = 1;
            // 
            // txt_idMedico
            // 
            this.txt_idMedico.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(179)))), ((int)(((byte)(237)))));
            this.txt_idMedico.Enabled = false;
            this.txt_idMedico.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.txt_idMedico.Location = new System.Drawing.Point(130, 152);
            this.txt_idMedico.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_idMedico.Name = "txt_idMedico";
            this.txt_idMedico.Size = new System.Drawing.Size(180, 22);
            this.txt_idMedico.TabIndex = 2;
            // 
            // txt_NumeroSS
            // 
            this.txt_NumeroSS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(179)))), ((int)(((byte)(237)))));
            this.txt_NumeroSS.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.txt_NumeroSS.Location = new System.Drawing.Point(130, 198);
            this.txt_NumeroSS.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_NumeroSS.Name = "txt_NumeroSS";
            this.txt_NumeroSS.Size = new System.Drawing.Size(180, 22);
            this.txt_NumeroSS.TabIndex = 3;
            // 
            // txt_NombrePaciente
            // 
            this.txt_NombrePaciente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(179)))), ((int)(((byte)(237)))));
            this.txt_NombrePaciente.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.txt_NombrePaciente.Location = new System.Drawing.Point(130, 56);
            this.txt_NombrePaciente.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_NombrePaciente.Name = "txt_NombrePaciente";
            this.txt_NombrePaciente.Size = new System.Drawing.Size(180, 22);
            this.txt_NombrePaciente.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.label2.Location = new System.Drawing.Point(21, 61);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Nombres";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.label3.Location = new System.Drawing.Point(21, 103);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Apellídos";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.label4.Location = new System.Drawing.Point(21, 157);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "ID Medico";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.label5.Location = new System.Drawing.Point(21, 200);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Número de seguro";
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(108)))), ((int)(((byte)(176)))));
            this.btnRegistrar.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.btnRegistrar.Location = new System.Drawing.Point(230, 288);
            this.btnRegistrar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(80, 39);
            this.btnRegistrar.TabIndex = 10;
            this.btnRegistrar.Text = "Registrar";
            this.btnRegistrar.UseVisualStyleBackColor = false;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(108)))), ((int)(((byte)(176)))));
            this.button2.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.button2.Location = new System.Drawing.Point(23, 288);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(80, 39);
            this.button2.TabIndex = 11;
            this.button2.Text = "Cerrar";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtFecha
            // 
            this.txtFecha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(179)))), ((int)(((byte)(237)))));
            this.txtFecha.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.txtFecha.Location = new System.Drawing.Point(130, 244);
            this.txtFecha.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtFecha.Name = "txtFecha";
            this.txtFecha.Size = new System.Drawing.Size(180, 22);
            this.txtFecha.TabIndex = 12;
            // 
            // txt_Sintomas
            // 
            this.txt_Sintomas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(179)))), ((int)(((byte)(237)))));
            this.txt_Sintomas.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.txt_Sintomas.Location = new System.Drawing.Point(433, 25);
            this.txt_Sintomas.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_Sintomas.Multiline = true;
            this.txt_Sintomas.Name = "txt_Sintomas";
            this.txt_Sintomas.Size = new System.Drawing.Size(312, 303);
            this.txt_Sintomas.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.label6.Location = new System.Drawing.Point(21, 247);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Fecha";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.label7.Location = new System.Drawing.Point(359, 28);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 13);
            this.label7.TabIndex = 17;
            this.label7.Text = "Sintomas:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.label9.Location = new System.Drawing.Point(765, 28);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "Medicamento:";
            // 
            // clbMedicamentos
            // 
            this.clbMedicamentos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(179)))), ((int)(((byte)(237)))));
            this.clbMedicamentos.Font = new System.Drawing.Font("Malgun Gothic", 8.25F);
            this.clbMedicamentos.FormattingEnabled = true;
            this.clbMedicamentos.Location = new System.Drawing.Point(848, 25);
            this.clbMedicamentos.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.clbMedicamentos.Name = "clbMedicamentos";
            this.clbMedicamentos.Size = new System.Drawing.Size(175, 310);
            this.clbMedicamentos.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Malgun Gothic", 12F);
            this.label1.Location = new System.Drawing.Point(153, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 21);
            this.label1.TabIndex = 23;
            this.label1.Text = "Ingresar Datos";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Proyecto_IS.Properties.Resources.notas_medicas;
            this.pictureBox1.Location = new System.Drawing.Point(20, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(56, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // NuevaConsulta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1030, 366);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.clbMedicamentos);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_Sintomas);
            this.Controls.Add(this.txtFecha);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnRegistrar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_NombrePaciente);
            this.Controls.Add(this.txt_NumeroSS);
            this.Controls.Add(this.txt_idMedico);
            this.Controls.Add(this.txt_ApellidosPaciente);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "NuevaConsulta";
            this.Text = "Nueva Consulta";
            this.Load += new System.EventHandler(this.NuevaConsulta_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txt_ApellidosPaciente;
        private System.Windows.Forms.TextBox txt_idMedico;
        private System.Windows.Forms.TextBox txt_NumeroSS;
        private System.Windows.Forms.TextBox txt_NombrePaciente;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtFecha;
        private System.Windows.Forms.TextBox txt_Sintomas;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckedListBox clbMedicamentos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}