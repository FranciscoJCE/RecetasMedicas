﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_IS
{
    public partial class InicioMedicos : Form
    {
       // private int id_Medico;
        //Ruta de conexion de la base de datos
        static string conexionruta = "server = LAPTOP-L3VPSIHP\\SQLEXPRESS01; integrated security = true ; database = Proyecto_IS";
        //Genera el objeto conexion para enlazar la base de datos
        SqlConnection conexion = new SqlConnection(conexionruta);
        
        public InicioMedicos()
        {
            //Al cargar el formulario muestra los Pacientes que estan registrados en la base de datos
            InitializeComponent();
            //Inicia la conexion
            conexion.Open();
            //Comando para cargar los valor de la tabla Paciente en el DataGridView del programa
            string query = "Select * from Paciente WHERE id_Medico = @id_Medico";
            using (SqlConnection conexion = new SqlConnection(conexionruta))
            using (SqlCommand comando = new SqlCommand(query, conexion)) 
            {
                comando.Parameters.AddWithValue("@id_Medico", SesionActual.idMedico);
                SqlDataAdapter data = new SqlDataAdapter(comando);
                DataTable Paciente = new DataTable();
                data.Fill(Paciente);
                //Rellena la DGV con el contenido de la tabla Paciente
                dgv_HistorialMedico.DataSource = Paciente;
            }
        }

        private void btnNuevaConsulta_Click(object sender, EventArgs e)
        {
            conexion.Close();
            if (dgv_HistorialMedico.CurrentRow != null)
            {
                int idPaciente = Convert.ToInt32(dgv_HistorialMedico.CurrentRow.Cells["id_Paciente"].Value);
                SesionActual.idPacienteSeleccionado = idPaciente;
                NuevaConsulta consulta = new NuevaConsulta();
                consulta.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Por favor, selecciona un paciente de la lista.");
            }
            /*NuevaConsulta consulta = new NuevaConsulta();
            consulta.Show();
            this.Close();*/
        }
        private void dgvPacientes_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int idPaciente = Convert.ToInt32(dgv_HistorialMedico.Rows[e.RowIndex].Cells["id_Paciente"].Value);

                // Guardar el ID del paciente en la sesión
                SesionActual.idPacienteSeleccionado = idPaciente;

                // Abrir NuevaConsulta
                NuevaConsulta nueva = new NuevaConsulta();
                nueva.ShowDialog();

                // Limpiar el ID después de usarlo
                SesionActual.idPacienteSeleccionado = null;
            }
        }
        private void btnCerrar_Sesion_Click(object sender, EventArgs e)
        {
            Form1 menu = new Form1();  
            menu.Show();
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            NuevoRegistrocs registrar = new NuevoRegistrocs();
            registrar.ShowDialog();
            this.Close();
        }
    }
}
