Create DataBase Proyecto_IS

use Proyecto_IS

Create table Hospital(
id_Hospital int primary key not null,
Direccion varchar(100) not null,
horario time,
Consultorios int not null,
num_Hospital int not null,
CP_Hospital int not null,
nom_Hospital varchar(50))

Create table Medico(
id_Medico int primary key not null,
Cedula_Medico int not null,
Especialidad_Medica varchar(50),
Edad_Medico int not null,
num_Consultorio varchar(3),
nom_Medico varchar(30),
apellido_Medico varchar(30),
id_Hospital int not null, 
constraint fk_id_Hospital foreign key (id_Hospital) references Hospital(id_Hospital))

Create table Farmaceutico(
id_Farmaceutico int primary key not null,
nom_Farmaceutico varchar(30),
Apellido_Farmaceutico varchar(30),
cedula_Farmaceutico int,
edad_Farmaceutico int not null,
id_Hospital int not null,
CONSTRAINT fk_id_Hospital_Farmaceutico foreign key (id_Hospital) REFERENCES Hospital(id_Hospital))

Create table Paciente(
id_Paciente int identity(1,1) primary key not null,
nom_Paciente varchar (30),
apellido_Paciente varchar(30),
id_Medico int not null,
CONSTRAINT fk_id_Medico foreign key (id_Medico) REFERENCES Medico(id_Medico),
num_SeguroS int not null)
--Medicamento
Create table Medicamento(
id_Medicamento int primary key identity(1,1) not null,
nom_Medicamento varchar(30) not null,
contenido_Medicamento varchar(50),
dosis_Medicamento varchar(50),
disponibilidad_Medicamento int,
prox_Entrega datetime)
--Receta
Create table Receta(
id_Receta int primary key identity(1,1) not null,
sintomas varchar(500) not null,
id_Paciente int,
CONSTRAINT fk_id_Paciente_Receta foreign key (id_Paciente) REFERENCES Paciente(id_Paciente),
id_Medico int,
CONSTRAINT fk_id_Medico_Receta foreign key (id_Medico) REFERENCES Medico(id_Medico),
fecha_Receta datetime)

Create Table RecetaMedicamento(
id_Receta int not null,
id_Medicamento int not null,
dosis varchar(50),
CONSTRAINT fk_Receta_idReceta FOREIGN KEY (id_Receta) REFERENCES Receta(id_Receta),
CONSTRAINT fk_Receta_idMedicamento FOREIGN KEY (id_Medicamento) REFERENCES Medicamento(id_Medicamento))
--Inio de sesion para medicos
Create table LogMedicos(
usuario varchar(30),
contrase�a varchar(30),
id_Medico int,
CONSTRAINT fk_LogMedicos_id foreign key(id_Medico) REFERENCES Medico(id_Medico)
)

Select * from Medico
Select * from Hospital
Select * from Paciente
Select * from LogMedicos
Select * from Receta

Insert into Hospital values (1,'Av. Zapata','10:00', 11, 3,22111,'Hospital Quezada')
--alter table Paciente drop column id_Hospital
Insert into Medico values (1,1231,'Pediatria',30,10,'Mario','Mendez',1)
Insert into Medico values (2,3211,'Medicina general',35,20,'Martin','Guerra',1)
Insert into Paciente values('Mereocrio', 'Menendez',1,12123123)
Insert into Paciente values('Menecio','Martinez',1,1231231323)
Insert into Paciente values('Mario','Bros',1,131564654)
Insert into Paciente values('Polo','Barrios',1,54646874)
Insert into Paciente values('Pablo','Montes',1,6564561)

Insert into LogMedicos values('Admin','123',1)

delete from Paciente where id_Paciente like 1

Update Paciente SET nom_Paciente = 'Roberto', apellido_Paciente = 'Contreras', num_SeguroS = 123132155 WHERE id_Paciente = 1;
Drop table Paciente
alter table Paciente drop fk_id_Medico
alter table Paciente drop column id_Hospital
alter table Paciente alter column id_Paciente int identity(1,1) primary key
Select * from Paciente where id_Medico like 2

Insert into Paciente values ('Roparo','Mendigas',2,4594123)
Select * from LogMedicos where usuario = 'Admin' AND contrase�a = 123

--insetar Medicamentos en la tabla
INSERT INTO Medicamento (nom_Medicamento, contenido_Medicamento, dosis_Medicamento, disponibilidad_Medicamento, prox_Entrega)
VALUES
('Paracetamol', '500 mg tabletas', '1 tableta cada 8 horas', 100, '2025-12-01'),
('Ibuprofeno', '400 mg tabletas', '1 tableta cada 8 horas', 80, '2025-12-05'),
('Amoxicilina/�cido Clavul�nico', '875/125 mg tabletas', '1 tableta cada 12 horas', 55, '2025-12-13'),
('Metformina', '850 mg tabletas', '1 tableta cada 12 horas', 120, '2025-12-10'),
('Losart�n', '50 mg tabletas', '1 tableta diaria', 75, '2025-12-03'),
('Omeprazol', '20 mg c�psulas', '1 c�psula antes del desayuno', 90, '2025-12-08'),
('Salbutamol', '100 mcg inhalador', '2 inhalaciones cada 6 horas', 30, '2025-11-28'),
('Loratadina', '10 mg tabletas', '1 tableta diaria', 100, '2025-12-02'),
('Diclofenaco', '50 mg tabletas', '1 tableta cada 8 horas', 70, '2025-12-06'),
('Furosemida', '40 mg tabletas', '1 tableta diaria', 50, '2025-12-12'),
('Enalapril', '10 mg tabletas', '1 tableta cada 12 horas', 85, '2025-11-29'),
('Azitromicina', '500 mg tabletas', '1 tableta diaria por 3 d�as', 40, '2025-12-04'),
('Clonazepam', '2 mg tabletas', '1 tableta cada 12 horas', 35, '2025-12-15'),
('Insulina NPH', '10 mL frasco', '10 unidades antes de dormir', 25, '2025-11-27'),
('Atorvastatina', '20 mg tabletas', '1 tableta diaria', 95, '2025-12-07'),
('Prednisona', '5 mg tabletas', '1 tableta cada 12 horas', 60, '2025-12-11'),
('Naproxeno', '500 mg tabletas', '1 tableta cada 12 horas', 80, '2025-12-09'),
('Cetirizina', '10 mg tabletas', '1 tableta diaria', 110, '2025-12-01'),
('Amoxicilina/�cido Clavul�nico', '875/125 mg tabletas', '1 tableta cada 12 horas', 55, '2025-12-13'),
('Alprazolam', '0.5 mg tabletas', '1 tableta antes de dormir', 40, '2025-12-14');
INSERT INTO Medicamento (nom_Medicamento, contenido_Medicamento, dosis_Medicamento, disponibilidad_Medicamento, prox_Entrega)
VALUES ('Amoxicilina/�cido Clavul�nico', '875/125 mg tabletas', '1 tableta cada 12 horas', 55, '2025-12-13')

--Delete from Medicamento where nom_Medicamento like 'Amoxicilina/�cido Clavul�nico'

SELECT id_Medicamento, nom_Medicamento FROM Medicamento;

Select * from Medicamento

drop database Proyecto_IS
